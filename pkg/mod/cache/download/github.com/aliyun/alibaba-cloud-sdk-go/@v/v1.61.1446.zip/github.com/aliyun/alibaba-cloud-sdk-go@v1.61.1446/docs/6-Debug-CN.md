[← 超时](5-Timeout-CN.md) | 调试[(English)](6-Debug-EN.md) | [日志 →](7-Logger-CN.md)
***

# 调试
如果环境变量 `DEBUG=sdk` 存在, 所有的请求都将启用调试模式。

***
[← 超时](5-Timeout-CN.md) | 调试[(English)](6-Debug-EN.md) | [日志 →](7-Logger-CN.md)
