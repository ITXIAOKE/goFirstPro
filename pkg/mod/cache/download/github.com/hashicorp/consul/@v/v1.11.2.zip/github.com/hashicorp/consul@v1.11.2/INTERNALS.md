Moved to [docs/README.md](./docs/README.md).
