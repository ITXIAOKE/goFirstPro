//go:build !consulent
// +build !consulent

package api

var defaultNamespace = ""
var defaultPartition = ""
