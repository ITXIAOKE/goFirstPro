// +build !race

package race

const Enabled = false
