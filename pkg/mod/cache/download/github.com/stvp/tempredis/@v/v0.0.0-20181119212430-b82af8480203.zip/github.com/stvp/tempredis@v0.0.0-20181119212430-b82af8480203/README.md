tempredis
=========

`tempredis` is a Go package that makes it easy to start and stop temporary
`redis-server` processes.

[API documentation](http://godoc.org/github.com/stvp/tempredis)
