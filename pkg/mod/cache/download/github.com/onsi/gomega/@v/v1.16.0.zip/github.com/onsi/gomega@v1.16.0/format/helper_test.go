/*
Gomega's format test helper package.
*/

package format

// TruncateHelpText returns truncateHelpText.
// This function is only accessible during tests.
func TruncatedHelpText() string {
	return truncateHelpText
}
