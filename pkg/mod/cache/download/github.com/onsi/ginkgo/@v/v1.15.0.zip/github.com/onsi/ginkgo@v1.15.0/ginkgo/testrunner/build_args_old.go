// +build !go1.10

package testrunner

var (
	buildArgs = []string{"test", "-c", "-i"}
)
