package D

import "$ROOT_PATH$/C"

func DoIt() string {
	return C.DoIt()
}
