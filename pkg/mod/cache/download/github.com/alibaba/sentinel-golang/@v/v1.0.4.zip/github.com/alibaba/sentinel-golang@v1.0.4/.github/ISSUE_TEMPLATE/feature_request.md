---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

<!-- Here is for bug reports and feature requests ONLY! 

If you're looking for help, please check our mail list and the Gitter room.

Please try to use English to describe your issue, or at least provide a snippet of English translation.
-->

## Issue Description

Type: *feature request*

### Describe what feature you want

### Additional context

Add any other context or screenshots about the feature request here.
